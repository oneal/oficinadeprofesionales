<?php
/**
 * Created by Vignesh.
 * User: Vignesh
 */

if (file_exists('config/info.php')) {
    include('config/info.php');
}
if ($_SERVER['REQUEST_METHOD']=='POST') {
    if (isset($_POST['listing_submit'])) {

        $listing_code = $_POST["listing_id"];
        $user_code = $_POST["user_code"];

        $listing_name = $_POST["listing_name"];

        $user_details = mysqli_query($conn,"SELECT * FROM  " . TBL . "users where user_code='" . $user_code . "'");
        $user_details_row = mysqli_fetch_array($user_details);

        $user_id = $user_details_row['user_id'];  //User Id
        
        $listings_a = mysqli_query($conn,"SELECT * FROM  " . TBL . "listings where listing_code='" . $listing_code . "'");
        $listings_a_row = mysqli_fetch_array($listings_a);

// Basic Personal Details
        $first_name = $listings_a_row["first_name"];
        $last_name = $listings_a_row["last_name"];
        $mobile_number = $user_details_row["mobile_number"]; //User Mobile Number
        $email_id = $user_details_row["email_id"]; //User Email Id
        

        $register_mode = "Direct";
        $user_status = "Inactive";

// Common Listing Details

        $listing_mobile = $listings_a_row["listing_mobile"];
        $listing_email = $listings_a_row["listing_email"];
        $listing_website = $listings_a_row["listing_website"];
        $listing_address = $listings_a_row["listing_address"];
        $listing_description = addslashes($listings_a_row["listing_description"]);
        $listing_type_id = $listings_a_row["listing_type_id"];

        $country_id = $listings_a_row["country_id"];
        
        $state_id = "1";

        $city_id = $listings_a_row["city_id"];
        
        $profile_image = $listings_a_row["profile_image"];
        $gallery_image = $listings_a_row["gallery_image"];
        $cover_image = $listings_a_row["cover_image"];

        $category_id = $listings_a_row["category_id"];

        $sub_category_id = $listings_a_row["sub_category_id"];

        $service_id = $listings_a_row["service_id"];
        $service_image = $listings_a_row["service_image"];

// Listing Timing Details
        $opening_days = $listings_a_row["opening_days"];
        $opening_time = $listings_a_row["opening_time"];
        $closing_time = $listings_a_row["closing_time"];

// Listing Social Link Details
        $fb_link = $listings_a_row["fb_link"];
        $gplus_link = $listings_a_row["gplus_link"];
        $twitter_link = $listings_a_row["twitter_link"];

// Listing Location Details
        $google_map = $listings_a_row["google_map"];
        $threesixty_view = $listings_a_row["360_view"];
        
// Listing Video
        $listing_video = $listings_a_row["listing_video"];

// Listing Service Names Details

        $service_1_name = $listings_a_row["service_1_name"];

// Listing Offer Prices Details
        $service_1_price = $listings_a_row["service_1_price"];

// Listing Offer Details
        $service_1_detail = addslashes($listings_a_row["service_1_detail"]);

// Listing Offer image
        $service_1_image = $listings_a_row["service_1_image"];
        
// Listing Offer view more        
        $service_1_view_more = $listings_a_row["service_1_view_more"];

//Listing Other Informations
        
        $listing_info_question = $listings_a_row["listing_info_question"];
        $listing_info_answer = $listings_a_row["listing_info_answer"];
        
// Listing Status
        $listing_status = "Active";
        // $listing_status = "Pending";
        $payment_status = "Pending";

        function checkListingSlug($link, $counter=1){
            global $conn;
            $newLink = $link;
            do{
                $checkLink = mysqli_query($conn, "SELECT listing_id FROM " . TBL . "listings WHERE listing_slug = '$newLink'");
                if(mysqli_num_rows($checkLink) > 0){
                    $newLink = $link.''.$counter;
                    $counter++;
                } else {
                    break;
                }
            } while(1);

            return $newLink;
        }


        $listing_name1 = preg_replace('/[^A-Za-z0-9]/', ' ', $listing_name);
        $listing_slug = checkListingSlug($listing_name1);

//    Listing Insert Part Starts

        $listing_qry = "INSERT INTO " . TBL . "listings 
					(user_id, category_id, sub_category_id, service_id, service_image, listing_type_id, listing_name, listing_mobile, listing_email
					, listing_website, listing_description, listing_address, country_id, state_id, city_id, profile_image, cover_image
					, gallery_image, opening_days, opening_time, closing_time, fb_link, twitter_link, gplus_link, google_map
					, 360_view, listing_video, service_1_name, service_1_price, service_1_detail, service_1_image, service_1_view_more, service_2_name,service_2_price, service_2_image, service_3_name,service_3_price, service_3_image
					, service_4_name,service_4_price,service_4_image,service_5_name,service_5_price, service_5_image, service_6_name,service_6_price, service_6_image, listing_status
					, listing_info_question , listing_info_answer, payment_status, listing_slug, listing_cdt) 
					VALUES 
					('$user_id', '$category_id', '$sub_category_id', '$service_id', '$service_image', '$listing_type_id', '$listing_name', '$listing_mobile', '$listing_email', '$listing_website', '$listing_description', '$listing_address', '$country_id'
					, '$state_id', '$city_id', '$profile_image', '$cover_image'
					,'$gallery_image', '$opening_days', '$opening_time', '$closing_time', '$fb_link', '$twitter_link', '$gplus_link', '$google_map'
					,'$threesixty_view', '$listing_video', '$service_1_name', '$service_1_price', '$service_1_detail', '$service_1_image', '$service_1_view_more', '$service_2_name', '$service_2_price', '$service_2_image', '$service_3_name', '$service_3_price', '$service_3_image'
					, '$service_4_name', '$service_4_price', '$service_4_image', '$service_5_name', '$service_5_price', '$service_5_image', '$service_6_name', '$service_6_price', '$service_6_image', '$listing_status'
					, '$listing_info_question', '$listing_info_answer', '$payment_status', '$listing_slug', '$curDate')";

        $listing_res = mysqli_query($conn,$listing_qry);
        $ListingID = mysqli_insert_id($conn);
        $listlastID = $ListingID;

        switch (strlen($ListingID)) {
            case 1:
                $ListingID = '00' . $ListingID;
                break;
            case 2:
                $ListingID = '0' . $ListingID;
                break;
            default:
                $ListingID = $ListingID;
                break;
        }

        $ListCode = 'LIST' . $ListingID;

        $lisupqry = "UPDATE " . TBL . "listings 
					  SET listing_code = '$ListCode' 
					  WHERE listing_id = $listlastID";

        $lisupres = mysqli_query($conn,$lisupqry);

        //****************************    Top Service Providers listing count check and addition starts    *************************


        //**  To check the given category id is available on top_service_provider_table    ***

        $top_service_sql = "SELECT * FROM  " . TBL . "top_service_providers where top_service_provider_category_id='".$category_id."'";
        $top_service_sql_rs = mysqli_query($conn, $top_service_sql);
        $top_service_sql_count = mysqli_num_rows($top_service_sql_rs);

        if($top_service_sql_count > 0){  //if category ID available in top service provider

            $top_service_sql_row = mysqli_fetch_array($top_service_sql_rs);

            $top_service_provider_listings = $top_service_sql_row['top_service_provider_listings'];
            $top_service_provider_category_id = $top_service_sql_row['top_service_provider_category_id'];

            $top_service_provider_listings_array = explode(",", $top_service_provider_listings);

            $top_service_provider_listings_array_count = count($top_service_provider_listings_array);

            if($top_service_provider_listings_array_count <= 4){   //if Listings less than or equal to 4 means update top service provider

                $parts = $top_service_provider_listings_array;
                $parts[] = $ListingID;                                  //updating existing listings array with new listing ID

                $top_service_provider_listings_new = implode(',', $parts);

                $top_service_provider_sql = mysqli_query($conn,"UPDATE  " . TBL . "top_service_providers SET top_service_provider_listings = '$top_service_provider_listings_new'
     where top_service_provider_category_id='" . $top_service_provider_category_id . "'");

            }
        }

        //****************************    Top Service Providers listing count check and addition ends    *************************

        //****************************    Admin Primary email fetch starts    *************************

        $admin_primary_email_fetch = mysqli_query($conn,"SELECT * FROM " . TBL . "footer  WHERE footer_id = '1' ");
        $admin_primary_email_fetchrow = mysqli_fetch_array($admin_primary_email_fetch);
        $admin_primary_email = $admin_primary_email_fetchrow['admin_primary_email'];
        $admin_footer_copyright = $admin_primary_email_fetchrow['footer_copyright'];
        $admin_site_name = $admin_primary_email_fetchrow['website_address'];
        $admin_address = $admin_primary_email_fetchrow['footer_address'];

        //****************************    Admin Primary email fetch ends    *************************


        if ($lisupres) {

            $admin_email = $admin_primary_email; // Admin Email Id

//****************************    Admin email starts    *************************

            $to = $admin_email;
            $subject = "'.$admin_site_name.' -New Listing has been created";

            $message1 = '<style type="text/css" rel="stylesheet" media="all">
    /* Base ------------------------------ */
    
    @import url("https://fonts.googleapis.com/css?family=Nunito+Sans:400,700&display=swap");
    body{width:100%!important;height:100%;margin:0;-webkit-text-size-adjust:none}
a{color:#3869D4}
a img{border:none}
td{word-break:break-word}
.preheader{display:none!important;visibility:hidden;mso-hide:all;font-size:1px;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden}
body,td,th{font-family:"Nunito Sans",Helvetica,Arial,sans-serif}
h1{margin-top:0;color:#333;font-size:22px;font-weight:700;text-align:left}
h2{margin-top:0;color:#333;font-size:16px;font-weight:700;text-align:left}
h3{margin-top:0;color:#333;font-size:14px;font-weight:700;text-align:left}
td,th{font-size:16px}
p,ul,ol,blockquote{margin:.4em 0 1.1875em;font-size:16px;line-height:1.625}
p.sub{font-size:13px}
.align-right{text-align:right}
.align-left{text-align:left}
.align-center{text-align:center}
.button{background-color:#3869D4;border-top:10px solid #3869D4;border-right:18px solid #3869D4;border-bottom:10px solid #3869D4;border-left:18px solid #3869D4;display:inline-block;color:#FFF;text-decoration:none;border-radius:3px;box-shadow:0 2px 3px rgba(0,0,0,0.16);-webkit-text-size-adjust:none;box-sizing:border-box}
.button--green{background-color:#22BC66;border-top:10px solid #22BC66;border-right:18px solid #22BC66;border-bottom:10px solid #22BC66;border-left:18px solid #22BC66}
.button--red{background-color:#FF6136;border-top:10px solid #FF6136;border-right:18px solid #FF6136;border-bottom:10px solid #FF6136;border-left:18px solid #FF6136}
@media only screen and (max-width: 500px) {
.button{width:100%!important;text-align:center!important}
}
.attributes{margin:0 0 21px}
.attributes_content{background-color:#F4F4F7;padding:16px}
.attributes_item{padding:0}
.related{width:100%;margin:0;padding:25px 0 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
.related_item{padding:10px 0;color:#CBCCCF;font-size:15px;line-height:18px}
.related_item-title{display:block;margin:.5em 0 0}
.related_item-thumb{display:block;padding-bottom:10px}
.related_heading{border-top:1px solid #CBCCCF;text-align:center;padding:25px 0 10px}
.discount{width:100%;margin:0;padding:24px;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#F4F4F7;border:2px dashed #CBCCCF}
.discount_heading{text-align:center}
.discount_body{text-align:center;font-size:15px}
.social{width:auto}
.social td{padding:0;width:auto}
.social_icon{height:20px;margin:0 8px 10px;padding:0}
.purchase{width:100%;margin:0;padding:35px 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
.purchase_content{width:100%;margin:0;padding:25px 0 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
.purchase_item{padding:10px 0;color:#51545E;font-size:15px;line-height:18px}
.purchase_heading{padding-bottom:8px;border-bottom:1px solid #EAEAEC}
.purchase_heading p{margin:0;color:#85878E;font-size:12px}
.purchase_footer{padding-top:15px;border-top:1px solid #EAEAEC}
.purchase_total{margin:0;text-align:right;font-weight:700;color:#333}
.purchase_total--label{padding:0 15px 0 0}
body{background-color:#F4F4F7;color:#51545E}
p{color:#51545E}
p.sub{color:#6B6E76}
.email-wrapper{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#F4F4F7}
.email-content{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
.email-masthead{padding:25px 0;text-align:center}
.email-masthead_logo{width:94px}
.email-masthead_name{font-size:16px;font-weight:700;color:#A8AAAF;text-decoration:none;text-shadow:0 1px 0 #fff}
.email-body{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#FFF}
.email-body_inner{width:570px;margin:0 auto;padding:0;-premailer-width:570px;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#FFF}
.email-footer{width:570px;margin:0 auto;padding:0;-premailer-width:570px;-premailer-cellpadding:0;-premailer-cellspacing:0;text-align:center}
.email-footer p{color:#6B6E76}
.body-action{width:100%;margin:30px auto;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;text-align:center}
.body-sub{margin-top:25px;padding-top:25px;border-top:1px solid #EAEAEC}
.content-cell{padding:35px}
@media only screen and (max-width: 600px) {
.email-body_inner,.email-footer{width:100%!important}
}
@media (prefers-color-scheme: dark) {
body,.email-body,.email-body_inner,.email-content,.email-wrapper,.email-masthead,.email-footer{background-color:#333!important;color:#FFF!important}
p,ul,ol,blockquote,h1,h2,h3{color:#FFF!important}
.attributes_content,.discount{background-color:#222!important}
.email-masthead_name{text-shadow:none!important}
}
    </style>
   
    <style type="text/css">
      .f-fallback  {
        font-family: Arial, sans-serif;
      }
    </style>
 
  </head>
  <body>
<span class="preheader">Thanks for trying out [Product Name]. We’ve pulled together some information and resources to help you get started.</span>
<table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation">
    <tr>
        <td align="center">
            <table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr>
                    <td class="email-masthead">
                        <a href="https://example.com" class="f-fallback email-masthead_name">
                            '.$admin_site_name.'
                        </a>
                    </td>
                </tr>
                <!-- Email Body -->
                <tr>
                    <td class="email-body" width="100%" cellpadding="0" cellspacing="0">
                        <table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
                            <!-- Body content -->
                            <tr>
                                <td class="content-cell">
                                    <div class="f-fallback">
                                        <h1>Dear Admin!</h1>
                                        <p>A New ' . $listing_name . '.Listing has been successfully created.</p>
                                        <!-- Action -->
                                        <p>For reference, here\'s the listing information:</p >
                                        <table class="attributes" width = "100%" cellpadding = "0" cellspacing = "0" role = "presentation" >
                                            <tr >
                                                <td class="attributes_content" >
                                                    <table width = "100%" cellpadding = "0" cellspacing = "0" role = "presentation" >
                                                        <tr >
                                                            <td class="attributes_item" >
                                    <span class="f-fallback" >
              <strong > Listing name:</strong > ' . $listing_name . '
            </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="attributes_item">
                                    <span class="f-fallback">
              <strong>Mobile Number :</strong> ' . $mobile_number . '
            </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="attributes_item">
                                    <span class="f-fallback">
              <strong>Email Id :</strong> ' . $email_id . '
            </span>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table class="email-footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
                            <tr>
                                <td class="content-cell" align="center">
                                    <p class="f-fallback sub align-center">&copy; '.$admin_footer_copyright.' '.$admin_site_name.'. All rights reserved.</p>
                                    <p class="f-fallback sub align-center">
                                        '.$admin_site_name.'
                                        <br>'.$admin_address.'
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>';

            $headers = "From: " . "$email_id" . "\r\n";
            $headers .= "Reply-To: " . "$email_id" . "\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=utf-8\r\n";


            mail($to, $subject, $message1, $headers); //admin email


//****************************    Admin email ends    *************************

//****************************    Client email starts    *************************

            $to1 = $email_id;
            $subject1 = "'.$admin_site_name.' Listing Creation Successful";

            $message2 = '<style type="text/css" rel="stylesheet" media="all">
    /* Base ------------------------------ */
    
    @import url("https://fonts.googleapis.com/css?family=Nunito+Sans:400,700&display=swap");
    body{width:100%!important;height:100%;margin:0;-webkit-text-size-adjust:none}
a{color:#3869D4}
a img{border:none}
td{word-break:break-word}
.preheader{display:none!important;visibility:hidden;mso-hide:all;font-size:1px;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden}
body,td,th{font-family:"Nunito Sans",Helvetica,Arial,sans-serif}
h1{margin-top:0;color:#333;font-size:22px;font-weight:700;text-align:left}
h2{margin-top:0;color:#333;font-size:16px;font-weight:700;text-align:left}
h3{margin-top:0;color:#333;font-size:14px;font-weight:700;text-align:left}
td,th{font-size:16px}
p,ul,ol,blockquote{margin:.4em 0 1.1875em;font-size:16px;line-height:1.625}
p.sub{font-size:13px}
.align-right{text-align:right}
.align-left{text-align:left}
.align-center{text-align:center}
.button{background-color:#3869D4;border-top:10px solid #3869D4;border-right:18px solid #3869D4;border-bottom:10px solid #3869D4;border-left:18px solid #3869D4;display:inline-block;color:#FFF;text-decoration:none;border-radius:3px;box-shadow:0 2px 3px rgba(0,0,0,0.16);-webkit-text-size-adjust:none;box-sizing:border-box}
.button--green{background-color:#22BC66;border-top:10px solid #22BC66;border-right:18px solid #22BC66;border-bottom:10px solid #22BC66;border-left:18px solid #22BC66}
.button--red{background-color:#FF6136;border-top:10px solid #FF6136;border-right:18px solid #FF6136;border-bottom:10px solid #FF6136;border-left:18px solid #FF6136}
@media only screen and (max-width: 500px) {
.button{width:100%!important;text-align:center!important}
}
.attributes{margin:0 0 21px}
.attributes_content{background-color:#F4F4F7;padding:16px}
.attributes_item{padding:0}
.related{width:100%;margin:0;padding:25px 0 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
.related_item{padding:10px 0;color:#CBCCCF;font-size:15px;line-height:18px}
.related_item-title{display:block;margin:.5em 0 0}
.related_item-thumb{display:block;padding-bottom:10px}
.related_heading{border-top:1px solid #CBCCCF;text-align:center;padding:25px 0 10px}
.discount{width:100%;margin:0;padding:24px;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#F4F4F7;border:2px dashed #CBCCCF}
.discount_heading{text-align:center}
.discount_body{text-align:center;font-size:15px}
.social{width:auto}
.social td{padding:0;width:auto}
.social_icon{height:20px;margin:0 8px 10px;padding:0}
.purchase{width:100%;margin:0;padding:35px 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
.purchase_content{width:100%;margin:0;padding:25px 0 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
.purchase_item{padding:10px 0;color:#51545E;font-size:15px;line-height:18px}
.purchase_heading{padding-bottom:8px;border-bottom:1px solid #EAEAEC}
.purchase_heading p{margin:0;color:#85878E;font-size:12px}
.purchase_footer{padding-top:15px;border-top:1px solid #EAEAEC}
.purchase_total{margin:0;text-align:right;font-weight:700;color:#333}
.purchase_total--label{padding:0 15px 0 0}
body{background-color:#F4F4F7;color:#51545E}
p{color:#51545E}
p.sub{color:#6B6E76}
.email-wrapper{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#F4F4F7}
.email-content{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
.email-masthead{padding:25px 0;text-align:center}
.email-masthead_logo{width:94px}
.email-masthead_name{font-size:16px;font-weight:700;color:#A8AAAF;text-decoration:none;text-shadow:0 1px 0 #fff}
.email-body{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#FFF}
.email-body_inner{width:570px;margin:0 auto;padding:0;-premailer-width:570px;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#FFF}
.email-footer{width:570px;margin:0 auto;padding:0;-premailer-width:570px;-premailer-cellpadding:0;-premailer-cellspacing:0;text-align:center}
.email-footer p{color:#6B6E76}
.body-action{width:100%;margin:30px auto;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;text-align:center}
.body-sub{margin-top:25px;padding-top:25px;border-top:1px solid #EAEAEC}
.content-cell{padding:35px}
@media only screen and (max-width: 600px) {
.email-body_inner,.email-footer{width:100%!important}
}
@media (prefers-color-scheme: dark) {
body,.email-body,.email-body_inner,.email-content,.email-wrapper,.email-masthead,.email-footer{background-color:#333!important;color:#FFF!important}
p,ul,ol,blockquote,h1,h2,h3{color:#FFF!important}
.attributes_content,.discount{background-color:#222!important}
.email-masthead_name{text-shadow:none!important}
}
    </style>
   
    <style type="text/css">
      .f-fallback  {
        font-family: Arial, sans-serif;
      }
    </style>
 
  </head>
  <body>
<span class="preheader">Thanks for trying out [Product Name]. We’ve pulled together some information and resources to help you get started.</span>
<table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation">
    <tr>
        <td align="center">
            <table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr>
                    <td class="email-masthead">
                        <a href="https://example.com" class="f-fallback email-masthead_name">
                            '.$admin_site_name.'
                        </a>
                    </td>
                </tr>
                <!-- Email Body -->
                <tr>
                    <td class="email-body" width="100%" cellpadding="0" cellspacing="0">
                        <table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
                            <!-- Body content -->
                            <tr>
                                <td class="content-cell">
                                    <div class="f-fallback">
                                        <h1>Hi, ' . $first_name . '!</h1>
                                        <p>Thanks for creating ' . $listing_name . '.Your Listing has been successfully created.</p>
                                        <!-- Action -->
                                        <p>For reference, here\'s your listing information:</p >
                                        <table class="attributes" width = "100%" cellpadding = "0" cellspacing = "0" role = "presentation" >
                                            <tr >
                                                <td class="attributes_content" >
                                                    <table width = "100%" cellpadding = "0" cellspacing = "0" role = "presentation" >
                                                        <tr >
                                                            <td class="attributes_item" >
                                    <span class="f-fallback" >
              <strong > Listing name:</strong > ' . $listing_name . '
            </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="attributes_item">
                                    <span class="f-fallback">
              <strong>Mobile Number :</strong> ' . $listing_mobile . '
            </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="attributes_item">
                                    <span class="f-fallback">
              <strong>Email Id :</strong> ' . $listing_email . '
            </span>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>

                                        <p>You can login into your dashboard then you check all details of listing.</p>
                                        <!-- Action -->
                                        <table class="body-action" align="center" width="100%" cellpadding="0" cellspacing="0" role="presentation">
                                            <tr>
                                                <td align="center">
                                                    <table width="100%" border="0" cellspacing="0" cellpadding="0" role="presentation">
                                                        <tr>
                                                            <td align="center">
                                                                <a href="{{action_url}}" class="f-fallback button" target="_blank">Access your dashboard</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                        <p>If you have any questions, feel free to <a href="mailto:{{support_email}}">email our customer success team</a>. (We\'re lightning quick at replying .)</p >
                                        <p> Thanks,
                                            <br > '.$admin_site_name.' Team</p>
                                        <p><strong>P.S.</strong> Need immediate help getting started? Check out our <a href="{{help_url}}">help documentation</a>. Or, just reply to this email, the [Product Name] support team is always ready to help!</p>
                                        <!-- Sub copy -->
                                        <table class="body-sub" role="presentation">
                                            <tr>
                                                <td>
                                                    <p class="f-fallback sub">If you’re having trouble with the button above, copy and paste the URL below into your web browser.</p>
                                                    <p class="f-fallback sub">{{action_url}}</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table class="email-footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
                            <tr>
                                <td class="content-cell" align="center">
                                    <p class="f-fallback sub align-center">&copy; '.$admin_footer_copyright.' '.$admin_site_name.'. All rights reserved.</p>
                                    <p class="f-fallback sub align-center">
                                        '.$admin_site_name.'
                                        <br>'.$admin_address.'
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>';

            $headers1 = "From: " . "$admin_email" . "\r\n";
            $headers1 .= "Reply-To: " . "$admin_email" . "\r\n";
            $headers1 .= "MIME-Version: 1.0\r\n";
            $headers1 .= "Content-Type: text/html; charset=utf-8\r\n";


            mail($to1, $subject1, $message2, $headers1); //admin email

//****************************    client email ends    *************************


            $_SESSION['status_msg'] = "New Duplicate Listing has been created Successfully!!!";

            header('Location: admin-all-listings.php');
        } else {

            $_SESSION['status_msg'] = "Oops!! Something Went Wrong Try Later!!!";

            header('Location: create-duplicate-listing.php');
        }

        //    Listing Insert Part Ends

    }
}else {

    $_SESSION['status_msg'] = "Oops!! Something Went Wrong Try Later!!!";

    header('Location: create-duplicate-listing.php');
}