<?php
/**
 * Created by Vignesh.
 * User: Vignesh
 */

if (file_exists('config/info.php')) {
    include('config/info.php');
}
if ($_SERVER['REQUEST_METHOD']=='POST') {
    if (isset($_POST['listing_submit'])) {

        $listing_id = $_POST["listing_id"];
        $listing_code = $_POST["listing_code"];

        $profile_image_old = $_POST["profile_image_old"];
        $cover_image_old = $_POST["cover_image_old"];
        $gallery_image_old = $_POST["gallery_image_old"];
        $service_image_old = $_POST["service_image_old"];

        $service_1_image_old = $_POST["service_1_image_old"];
//        $service_2_image_old = $_POST["service_2_image_old"];
//        $service_3_image_old = $_POST["service_3_image_old"];
//        $service_4_image_old = $_POST["service_4_image_old"];
//        $service_5_image_old = $_POST["service_5_image_old"];
//        $service_6_image_old = $_POST["service_6_image_old"];

        // Basic Personal Details
        $first_name = $_POST["first_name"];
        $last_name = $_POST["last_name"];
        $mobile_number = $_POST["mobile_number"];
        $email_id = $_POST["email_id"];

        $register_mode = "Direct";
//        $user_status = "Inactive";

// Common Listing Details
        $listing_name = $_POST["listing_name"];
        $listing_mobile = $_POST["listing_mobile"];
        $listing_email = $_POST["listing_email"];
        $listing_website = $_POST["listing_website"];
        $listing_address = $_POST["listing_address"];
        $listing_lat = $_POST["listing_lat"];
        $listing_lng = $_POST["listing_lng"];
        $listing_description = addslashes($_POST["listing_description"]);
        $listing_type_id = 1;

        $country_id = $_POST["country_id"];
        $service_locations = $_POST["service_locations"];
//        $state_id = $_POST["state_id"];

//        $country_id = "38";
        $state_id = "1";

        $city_id1 = $_POST["city_id"];
        $prefix = $fruitList = '';
        foreach ($city_id1 as $fruit)
        {
            $city_id .= $prefix .  $fruit ;
            $prefix = ',';
        }

//        $cities = "SELECT * FROM " . TBL . "cities WHERE city_name='$city_id1'";
//        $rs_cities = mysqli_query($conn,$cities);
//
//        if(mysqli_num_rows($rs_cities)>0) {
//            $cities_row = mysqli_fetch_array($rs_cities);
//
//            $city_id = $cities_row['city_id'];
//        }else{
//            $city_id = 10519;
//        }

        $category_id = $_POST["category_id"];

//        $prefix = $fruitList = '';
//        foreach ($category_id123 as $fruit)
//        {
//            $category_id .= $prefix .  $fruit ;
//            $prefix = ',';
//        }

        $sub_category_id123 = $_POST["sub_category_id"];

        $prefix = $fruitList = '';
        foreach ($sub_category_id123 as $fruit)
        {
            $sub_category_id .= $prefix .  $fruit ;
            $prefix = ',';
        }

        $service_id123 = $_POST["service_id"];

        $prefix1 = $fruitList = '';
        foreach ($service_id123 as $fruit1)
        {
            $service_id .= $prefix1 .  $fruit1 ;
            $prefix1 = ',';
        }




// Listing Timing Details
        $opening_days = $_POST["opening_days"];
        $opening_time = $_POST["opening_time"];
        $closing_time = $_POST["closing_time"];

// Listing Social Link Details
        $fb_link = $_POST["fb_link"];
        $gplus_link = $_POST["gplus_link"];
        $twitter_link = $_POST["twitter_link"];

// Listing Location Details
        $google_map = $_POST["google_map"];
        $threesixty_view = $_POST["360_view"];

        $listing_video123 = $_POST["listing_video"];

        // Listing Video

        $prefix6 = $fruitList = '';
        foreach ($listing_video123 as $fruit6)
        {
            $listing_video1 = $prefix6 .  $fruit6 ;
            $listing_video .= addslashes($listing_video1);
            $prefix6 = '|';
        }

// Listing Service Names Details

        $service_1_name123 = $_POST["service_1_name"];

        $prefix1 = $fruitList = '';
        foreach ($service_1_name123 as $fruit1)
        {
            $service_1_name .= $prefix1 .  $fruit1 ;
            $prefix1 = ',';
        }

//        $service_2_name = $_POST["service_2_name"];
//        $service_3_name = $_POST["service_3_name"];
//        $service_4_name = $_POST["service_4_name"];
//        $service_5_name = $_POST["service_5_name"];
//        $service_6_name = $_POST["service_6_name"];

// Listing Offer Prices Details
        $service_1_price123 = $_POST["service_1_price"];

        $prefix1 = $fruitList = '';
        foreach ($service_1_price123 as $fruit1)
        {
            $service_1_price .= $prefix1 .  $fruit1 ;
            $prefix1 = ',';
        }
//        $service_2_price = $_POST["service_2_price"];
//        $service_3_price = $_POST["service_3_price"];
//        $service_4_price = $_POST["service_4_price"];
//        $service_5_price = $_POST["service_5_price"];
//        $service_6_price = $_POST["service_6_price"];

        $service_2_price = 0;
        $service_3_price = 0;
        $service_4_price = 0;
        $service_5_price = 0;
        $service_6_price = 0;

// Listing Offer Details
        $service_1_detail123 = $_POST["service_1_detail"];
        $prefix1 = $fruitList = '';
        foreach ($service_1_detail123 as $fruit1)
        {
            $service_1_detail1 .= $prefix1 .  $fruit1 ;
            $service_1_detail .= addslashes($service_1_detail1);
            $prefix1 = ',';
        }

// Listing Offer View More
        $service_1_view_more123 = $_POST["service_1_view_more"];
        $prefix1 = $fruitList = '';
        foreach ($service_1_view_more123 as $fruit1)
        {
            $service_1_view_more .= $prefix1 .  $fruit1 ;
            $prefix1 = ',';
        }

//        $service_2_detail = $_POST["service_2_detail"];
//        $service_3_detail = $_POST["service_3_detail"];
//        $service_4_detail = $_POST["service_4_detail"];
//        $service_5_detail = $_POST["service_5_detail"];
//        $service_6_detail = $_POST["service_6_detail"];

//Listing Other Informations
        $listing_info_question123 = $_POST["listing_info_question"];
        $prefix1 = $fruitList = '';
        foreach ($listing_info_question123 as $fruit1)
        {
            $listing_info_question .= $prefix1 .  $fruit1 ;
            $prefix1 = ',';
        }

        $listing_info_answer123 = $_POST["listing_info_answer"];
        $prefix1 = $fruitList = '';
        foreach ($listing_info_answer123 as $fruit1)
        {
            $listing_info_answer .= $prefix1 .  $fruit1 ;
            $prefix1 = ',';
        }

// Listing Status
//        $listing_status = "Active";
        // $listing_status = "Pending";
        $payment_status = "Pending";

        function checkListingSlug($link,$listing_id, $counter=1){
            global $conn;
            $newLink = $link;
            do{
                $checkLink = mysqli_query($conn, "SELECT listing_id FROM " . TBL . "listings WHERE listing_slug = '$newLink' AND listing_id != '$listing_id'");
                if(mysqli_num_rows($checkLink) > 0){
                    $newLink = $link.''.$counter;
                    $counter++;
                } else {
                    break;
                }
            } while(1);

            return $newLink;
        }


        $listing_name1 = preg_replace('/[^A-Za-z0-9]/', ' ', $listing_name);
        $listing_slug = checkListingSlug($listing_name1,$listing_id);

//    Condition to get User Id starts

        if (isset($_POST['user_code']) && !empty($_POST['user_code'])) {
            $user_code = $_POST['user_code'];
            $user_details = mysqli_query($conn,"SELECT * FROM  " . TBL . "users where user_code='" . $user_code . "'");
            $user_details_row = mysqli_fetch_array($user_details);

            $user_id = $user_details_row['user_id'];  //User Id

            if($user_details_row['user_status'] == 'Active'){
                // Listing Status
                $listing_status = "Active";
            }else{
                // Listing Status
                $listing_status = "Inactive";
            }

        } else {

            $user_status = "Inactive";

            $qry = "INSERT INTO " . TBL . "users 
					(first_name, last_name, email_id, mobile_number, register_mode, user_status, user_cdt) 
					VALUES ('$first_name', '$last_name', '$email_id', '$mobile_number','$register_mode', '$user_status', '$curDate')";

            $res = mysqli_query($conn,$qry);
            $LID = mysqli_insert_id($conn);
            $lastID = $LID;

            switch (strlen($LID)) {
                case 1:
                    $LID = '00' . $LID;
                    break;
                case 2:
                    $LID = '0' . $LID;
                    break;
                default:
                    $LID = $LID;
                    break;
            }

            $userID = 'USER' . $LID;

            $upqry = "UPDATE " . TBL . "users 
					  SET user_code = '$userID' 
					  WHERE user_id = $lastID";

            //echo $upqry; die();
            $upres = mysqli_query($conn,$upqry);

            $user_id = $lastID; //User Id

            // Listing Status
            $listing_status = "Inactive";
        }
//    Condition to get User Id Ends


//************************  Profile Image Upload starts  **************************

        if (!empty($_FILES['profile_image']['name'])) {
            $file = rand(1000, 100000) . $_FILES['profile_image']['name'];
            $file_loc = $_FILES['profile_image']['tmp_name'];
            $file_size = $_FILES['profile_image']['size'];
            $file_type = $_FILES['profile_image']['type'];
            $folder = "../images/listings/";
            $new_size = $file_size / 1024;
            $new_file_name = strtolower($file);
            $event_image = str_replace(' ', '-', $new_file_name);
            move_uploaded_file($file_loc, $folder . $event_image);
            $profile_image = $event_image;
        }else {
            $profile_image = $profile_image_old;
        }
//************************  Profile Image Upload Ends  **************************

//************************  Cover Image Upload starts  **************************

        if (!empty($_FILES['cover_image']['name'])) {
            $file = rand(1000, 100000) . $_FILES['cover_image']['name'];
            $file_loc = $_FILES['cover_image']['tmp_name'];
            $file_size = $_FILES['cover_image']['size'];
            $file_type = $_FILES['cover_image']['type'];
            $folder = "../images/slider/";
            $new_size = $file_size / 1024;
            $new_file_name = strtolower($file);
            $event_image = str_replace(' ', '-', $new_file_name);
            move_uploaded_file($file_loc, $folder . $event_image);
            $cover_image = $event_image;
        } else {
            $cover_image = $cover_image_old;
        }
//************************  Cover Image Upload ends  **************************

// ************************  Gallery Image Upload starts  **************************

        $all_gallery_image = $_FILES['gallery_image'];

        if (count(array_filter($_FILES['gallery_image']['name'])) <= 0) {
            $gallery_image = $gallery_image_old;
        } else {


            for ($k = 0; $k < count($all_gallery_image); $k++) {


                if (!empty($all_gallery_image['name'][$k])) {
                    $file1 = rand(1000, 100000) . $all_gallery_image['name'][$k];
                    $file_loc1 = $all_gallery_image['tmp_name'][$k];
                    $file_size1 = $all_gallery_image['size'][$k];
                    $file_type1 = $all_gallery_image['type'][$k];
                    $folder1 = "../images/listings/";
                    $new_size1 = $file_size1 / 1024;
                    $new_file_name1 = strtolower($file1);
                    $event_image1 = str_replace(' ', '-', $new_file_name1);
                    move_uploaded_file($file_loc1, $folder1 . $event_image1);
                    $gallery_image1[] = $event_image1;

                }
                $gallery_image = implode(",", $gallery_image1);

            }
        }

        // ************************  Gallery Image Upload ends  **************************

// ************************  Service Image Upload starts  **************************

        $all_service_image = $_FILES['service_image'];

        if (count(array_filter($_FILES['service_image']['name'])) <= 0) {
            $service_image = $service_image_old;
        } else {

            for ($k = 0; $k < count($all_service_image); $k++) {

                if (!empty($_FILES['service_image']['name'][$k])) {
                    $file = rand(1000, 100000) . $_FILES['service_image']['name'][$k];
                    $file_loc = $_FILES['service_image']['tmp_name'][$k];
                    $file_size = $_FILES['service_image']['size'][$k];
                    $file_type = $_FILES['service_image']['type'][$k];
                    $folder = "../images/services/";
                    $new_size = $file_size / 1024;
                    $new_file_name = strtolower($file);
                    $event_image = str_replace(' ', '-', $new_file_name);
                    move_uploaded_file($file_loc, $folder . $event_image);
                    $service_image[] = $event_image;
                }
                $service_image = implode(",", $service_image1);
            }
        }

// ************************  Service Image Upload ends  **************************

// ************************  Offer Image Upload Starts  **************************

        $all_service_1_image = $_FILES['service_1_image'];

        if (count(array_filter($_FILES['service_1_image']['name'])) <= 0) {
            $service_1_image = $service_1_image_old;
        } else {
            for ($k = 0; $k < count($all_service_1_image); $k++) {

                if (!empty($_FILES['service_1_image']['name'][$k])) {
                    $file = rand(1000, 100000) . $_FILES['service_1_image']['name'][$k];
                    $file_loc = $_FILES['service_1_image']['tmp_name'][$k];
                    $file_size = $_FILES['service_1_image']['size'][$k];
                    $file_type = $_FILES['service_1_image']['type'][$k];
                    $folder = "../images/services/";
                    $new_size = $file_size / 1024;
                    $new_file_name = strtolower($file);
                    $event_image = str_replace(' ', '-', $new_file_name);
                    move_uploaded_file($file_loc, $folder . $event_image);
                    $service_1_image1[] = $event_image;
                }
                $service_1_image = implode(",", $service_1_image1);
            }
        }
// ************************  Offer Image Upload ends  **************************

//    Listing Update Part Starts


//    $listing_qry = "INSERT INTO " . TBL . "listings
//					(user_id, category_id, listing_type_id, listing_name, listing_description, listing_address, city_id, cover_image
//					,gallery_image,opening_days, opening_time, closing_time, fb_link, twitter_link, gplus_link, google_map
//					,360_view,service_1_name,service_1_image, service_2_name, service_2_image, service_3_name, service_3_image
//					, service_4_name,service_4_image,service_5_name, service_5_image, service_6_name, service_6_image, listing_status
//					, payment_status, listing_cdt)
//					VALUES
//					('$user_id', '$category_id', '$listing_type_id', '$listing_name', '$listing_description', '$listing_address', '$city_id', '$cover_image'
//					,'$gallery_image', '$opening_days', '$opening_time', '$closing_time', '$fb_link', '$twitter_link', '$gplus_link', '$google_map'
//					,'$threesixty_view', '$service_1_name', '$service_1_image', '$service_2_name', '$service_2_image', '$service_3_name', '$service_3_image'
//					, '$service_4_name', '$service_4_image', '$service_5_name', '$service_5_image', '$service_6_name', '$service_6_image', '$listing_status'
//					, '$payment_status', '$curDate')";


        $listing_qry =
            "UPDATE  " . TBL . "listings  SET user_id='" . $user_id . "', category_id='" . $category_id . "', sub_category_id='" . $sub_category_id . "', service_id='" . $service_id . "'
            , service_image='" . $service_image . "', listing_type_id='" . $listing_type_id . "', listing_mobile='" . $listing_mobile . "', listing_email='" . $listing_email . "'
            , service_locations='" . $service_locations . "', listing_lat='" . $listing_lat . "', listing_lng='" . $listing_lng . "'
    , listing_website='" . $listing_website . "', listing_name='" . $listing_name . "',listing_description='" . $listing_description . "', listing_address='" . $listing_address . "'
    ,country_id='" . $country_id . "',state_id='" . $state_id . "',city_id='" . $city_id . "',profile_image='" . $profile_image . "', cover_image='" . $cover_image . "'
    ,gallery_image='" . $gallery_image . "',opening_days='" . $opening_days . "', opening_time='" . $opening_time . "'
    , closing_time='" . $closing_time . "',fb_link='" . $fb_link . "',twitter_link='" . $twitter_link . "'
    ,gplus_link='" . $gplus_link . "', google_map='" . $google_map . "',360_view='" . $threesixty_view . "', listing_video ='" . $listing_video . "'
    ,service_1_name='" . $service_1_name . "',service_1_price='" . $service_1_price . "', service_1_detail='" . $service_1_detail . "'
    ,service_1_image='" . $service_1_image . "', service_1_view_more='" . $service_1_view_more . "', service_2_name='" . $service_2_name . "' ,service_2_price='" . $service_2_price . "' 
    ,service_2_image='" . $service_2_image . "',service_3_name='" . $service_3_name . "'  ,service_3_price='" . $service_3_price . "'
    ,service_3_image='" . $service_3_image . "', service_4_name='" . $service_4_name . "' ,service_4_price='" . $service_4_price . "'
    ,service_4_image='" . $service_4_image . "',service_5_name='" . $service_5_name . "'  ,service_5_price='" . $service_5_price . "'
    ,service_5_image='" . $service_5_image . "', service_6_name='" . $service_6_name . "' ,service_6_price='" . $service_6_price . "' 
    ,service_6_image='" . $service_6_image . "', payment_status='" . $payment_status . "', listing_info_question ='" . $listing_info_question . "'
    , listing_info_answer ='" . $listing_info_answer. "', listing_slug ='" . $listing_slug. "' where listing_id='" . $listing_id . "'";

        $listing_res = mysqli_query($conn,$listing_qry);


        //****************************    Admin Primary email fetch starts    *************************

        $admin_primary_email_fetch = mysqli_query($conn, "SELECT * FROM " . TBL . "footer  WHERE footer_id = '1' ");
        $admin_primary_email_fetchrow = mysqli_fetch_array($admin_primary_email_fetch);
        $admin_primary_email = $admin_primary_email_fetchrow['admin_primary_email'];
        $admin_footer_copyright = $admin_primary_email_fetchrow['footer_copyright'];
        $admin_site_name = $admin_primary_email_fetchrow['website_address'];
        $admin_address = $admin_primary_email_fetchrow['footer_address'];

        //****************************    Admin Primary email fetch ends    *************************

        if ($listing_res) {

            $admin_email = $admin_primary_email; // Admin Email Id

            $webpage_full_link_with_login = $webpage_full_link. "login";  //URL Login Link

//****************************    Admin email starts    *************************

            $to = $admin_email;
            $subject = "'.$admin_site_name.' - Listing has been updated";

            $admin_sql_fetch = mysqli_query($conn,"SELECT * FROM " . TBL . "mail  WHERE mail_id = 9 "); //admin mail template fetch
            $admin_sql_fetch_row = mysqli_fetch_array($admin_sql_fetch);

            $mail_template_admin = $admin_sql_fetch_row['mail_template'];

            $message1 =   stripslashes(str_replace(array('\'.$admin_site_name.\'', '\' . $first_name . \'', '\' . $email_id . \''
            ,'\' . $mobile_number . \'', '\' . $listing_name . \'', '\' . $listing_email . \'', '\' . $listing_mobile . \'', '\'.$admin_footer_copyright.\'', '\'.$admin_address.\'', '\'.$webpage_full_link.\'','\'.$webpage_full_link_with_login.\'','\'.$admin_primary_email.\''),
                array(''.$admin_site_name.'', '' . $first_name . '', '' . $email_id . '','' . $mobile_number . '', '' . $listing_name . '', '' . $listing_email . '', '' . $listing_mobile . '', ''.$admin_footer_copyright.'', ''.$admin_address.'', ''.$webpage_full_link.'',''.$webpage_full_link_with_login.'',''.$admin_primary_email.''), $mail_template_admin));




//            $message1 = '<style type="text/css" rel="stylesheet" media="all">
//    /* Base ------------------------------ */
//
//    @import url("https://fonts.googleapis.com/css?family=Nunito+Sans:400,700&display=swap");
//    body{width:100%!important;height:100%;margin:0;-webkit-text-size-adjust:none}
//a{color:#3869D4}
//a img{border:none}
//td{word-break:break-word}
//.preheader{display:none!important;visibility:hidden;mso-hide:all;font-size:1px;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden}
//body,td,th{font-family:"Nunito Sans",Helvetica,Arial,sans-serif}
//h1{margin-top:0;color:#333;font-size:22px;font-weight:700;text-align:left}
//h2{margin-top:0;color:#333;font-size:16px;font-weight:700;text-align:left}
//h3{margin-top:0;color:#333;font-size:14px;font-weight:700;text-align:left}
//td,th{font-size:16px}
//p,ul,ol,blockquote{margin:.4em 0 1.1875em;font-size:16px;line-height:1.625}
//p.sub{font-size:13px}
//.align-right{text-align:right}
//.align-left{text-align:left}
//.align-center{text-align:center}
//.button{background-color:#3869D4;border-top:10px solid #3869D4;border-right:18px solid #3869D4;border-bottom:10px solid #3869D4;border-left:18px solid #3869D4;display:inline-block;color:#FFF;text-decoration:none;border-radius:3px;box-shadow:0 2px 3px rgba(0,0,0,0.16);-webkit-text-size-adjust:none;box-sizing:border-box}
//.button--green{background-color:#22BC66;border-top:10px solid #22BC66;border-right:18px solid #22BC66;border-bottom:10px solid #22BC66;border-left:18px solid #22BC66}
//.button--red{background-color:#FF6136;border-top:10px solid #FF6136;border-right:18px solid #FF6136;border-bottom:10px solid #FF6136;border-left:18px solid #FF6136}
//@media only screen and (max-width: 500px) {
//.button{width:100%!important;text-align:center!important}
//}
//.attributes{margin:0 0 21px}
//.attributes_content{background-color:#F4F4F7;padding:16px}
//.attributes_item{padding:0}
//.related{width:100%;margin:0;padding:25px 0 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
//.related_item{padding:10px 0;color:#CBCCCF;font-size:15px;line-height:18px}
//.related_item-title{display:block;margin:.5em 0 0}
//.related_item-thumb{display:block;padding-bottom:10px}
//.related_heading{border-top:1px solid #CBCCCF;text-align:center;padding:25px 0 10px}
//.discount{width:100%;margin:0;padding:24px;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#F4F4F7;border:2px dashed #CBCCCF}
//.discount_heading{text-align:center}
//.discount_body{text-align:center;font-size:15px}
//.social{width:auto}
//.social td{padding:0;width:auto}
//.social_icon{height:20px;margin:0 8px 10px;padding:0}
//.purchase{width:100%;margin:0;padding:35px 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
//.purchase_content{width:100%;margin:0;padding:25px 0 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
//.purchase_item{padding:10px 0;color:#51545E;font-size:15px;line-height:18px}
//.purchase_heading{padding-bottom:8px;border-bottom:1px solid #EAEAEC}
//.purchase_heading p{margin:0;color:#85878E;font-size:12px}
//.purchase_footer{padding-top:15px;border-top:1px solid #EAEAEC}
//.purchase_total{margin:0;text-align:right;font-weight:700;color:#333}
//.purchase_total--label{padding:0 15px 0 0}
//body{background-color:#F4F4F7;color:#51545E}
//p{color:#51545E}
//p.sub{color:#6B6E76}
//.email-wrapper{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#F4F4F7}
//.email-content{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
//.email-masthead{padding:25px 0;text-align:center}
//.email-masthead_logo{width:94px}
//.email-masthead_name{font-size:16px;font-weight:700;color:#A8AAAF;text-decoration:none;text-shadow:0 1px 0 #fff}
//.email-body{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#FFF}
//.email-body_inner{width:570px;margin:0 auto;padding:0;-premailer-width:570px;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#FFF}
//.email-footer{width:570px;margin:0 auto;padding:0;-premailer-width:570px;-premailer-cellpadding:0;-premailer-cellspacing:0;text-align:center}
//.email-footer p{color:#6B6E76}
//.body-action{width:100%;margin:30px auto;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;text-align:center}
//.body-sub{margin-top:25px;padding-top:25px;border-top:1px solid #EAEAEC}
//.content-cell{padding:35px}
//@media only screen and (max-width: 600px) {
//.email-body_inner,.email-footer{width:100%!important}
//}
//@media (prefers-color-scheme: dark) {
//body,.email-body,.email-body_inner,.email-content,.email-wrapper,.email-masthead,.email-footer{background-color:#333!important;color:#FFF!important}
//p,ul,ol,blockquote,h1,h2,h3{color:#FFF!important}
//.attributes_content,.discount{background-color:#222!important}
//.email-masthead_name{text-shadow:none!important}
//}
//    </style>
//
//    <style type="text/css">
//      .f-fallback  {
//        font-family: Arial, sans-serif;
//      }
//    </style>
//
//  </head>
//  <body>
//<span class="preheader">Thanks for trying out '.$admin_site_name.'. We’ve pulled together some information and resources to help you get started.</span>
//<table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation">
//    <tr>
//        <td align="center">
//            <table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
//                <tr>
//                    <td class="email-masthead">
//                        <a href="'.$webpage_full_link.'" class="f-fallback email-masthead_name">
//                            '.$admin_site_name.'
//                        </a>
//                    </td>
//                </tr>
//                <!-- Email Body -->
//                <tr>
//                    <td class="email-body" width="100%" cellpadding="0" cellspacing="0">
//                        <table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
//                            <!-- Body content -->
//                            <tr>
//                                <td class="content-cell">
//                                    <div class="f-fallback">
//                                        <h1>Dear Admin!</h1>
//                                        <p>An Existing ' . $listing_name . '.Listing has been successfully Updated.</p>
//                                        <!-- Action -->
//                                        <p>For reference, here\'s the listing information:</p >
//                                        <table class="attributes" width = "100%" cellpadding = "0" cellspacing = "0" role = "presentation" >
//                                            <tr >
//                                                <td class="attributes_content" >
//                                                    <table width = "100%" cellpadding = "0" cellspacing = "0" role = "presentation" >
//                                                        <tr >
//                                                            <td class="attributes_item" >
//                                    <span class="f-fallback" >
//              <strong > Listing name:</strong > ' . $listing_name . '
//            </span>
//                                                            </td>
//                                                        </tr>
//                                                        <tr>
//                                                            <td class="attributes_item">
//                                    <span class="f-fallback">
//              <strong>Mobile Number :</strong> ' . $mobile_number . '
//            </span>
//                                                            </td>
//                                                        </tr>
//                                                        <tr>
//                                                            <td class="attributes_item">
//                                    <span class="f-fallback">
//              <strong>Email Id :</strong> ' . $email_id . '
//            </span>
//                                                            </td>
//                                                        </tr>
//                                                    </table>
//                                                </td>
//                                            </tr>
//                                        </table>
//                                    </div>
//                                </td>
//                            </tr>
//                        </table>
//                    </td>
//                </tr>
//                <tr>
//                    <td>
//                        <table class="email-footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
//                            <tr>
//                                <td class="content-cell" align="center">
//                                    <p class="f-fallback sub align-center">&copy; '.$admin_footer_copyright.' '.$admin_site_name.'. All rights reserved.</p>
//                                    <p class="f-fallback sub align-center">
//                                        '.$admin_site_name.'
//                                        <br>'.$admin_address.'
//                                    </p>
//                                </td>
//                            </tr>
//                        </table>
//                    </td>
//                </tr>
//            </table>
//        </td>
//    </tr>
//</table>
//</body>';

            $headers = "From: " . "$email_id" . "\r\n";
            $headers .= "Reply-To: " . "$email_id" . "\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=utf-8\r\n";


            mail($to, $subject, $message1, $headers); //admin email


//****************************    Admin email ends    *************************

//****************************    Client email starts    *************************

            $to1 = $email_id;
            $subject1 = "'.$admin_site_name.' Listing Update Successful";

            $client_sql_fetch = mysqli_query($conn,"SELECT * FROM " . TBL . "mail  WHERE mail_id = 8 "); //User mail template fetch
            $client_sql_fetch_row = mysqli_fetch_array($client_sql_fetch);

            $mail_template_client = $client_sql_fetch_row['mail_template'];

            $message2 =   stripslashes(str_replace(array('\'.$admin_site_name.\'', '\' . $first_name . \'', '\' . $email_id . \''
            ,'\' . $mobile_number . \'', '\' . $listing_name . \'', '\' . $listing_email . \'', '\' . $listing_mobile . \'', '\'.$admin_footer_copyright.\'', '\'.$admin_address.\'', '\'.$webpage_full_link.\'','\'.$webpage_full_link_with_login.\'','\'.$admin_primary_email.\''),
                array(''.$admin_site_name.'', '' . $first_name . '', '' . $email_id . '','' . $mobile_number . '', '' . $listing_name . '', '' . $listing_email . '', '' . $listing_mobile . '', ''.$admin_footer_copyright.'', ''.$admin_address.'', ''.$webpage_full_link.'',''.$webpage_full_link_with_login.'',''.$admin_primary_email.''), $mail_template_client));


//            $message2 = '<style type="text/css" rel="stylesheet" media="all">
//    /* Base ------------------------------ */
//
//    @import url("https://fonts.googleapis.com/css?family=Nunito+Sans:400,700&display=swap");
//    body{width:100%!important;height:100%;margin:0;-webkit-text-size-adjust:none}
//a{color:#3869D4}
//a img{border:none}
//td{word-break:break-word}
//.preheader{display:none!important;visibility:hidden;mso-hide:all;font-size:1px;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden}
//body,td,th{font-family:"Nunito Sans",Helvetica,Arial,sans-serif}
//h1{margin-top:0;color:#333;font-size:22px;font-weight:700;text-align:left}
//h2{margin-top:0;color:#333;font-size:16px;font-weight:700;text-align:left}
//h3{margin-top:0;color:#333;font-size:14px;font-weight:700;text-align:left}
//td,th{font-size:16px}
//p,ul,ol,blockquote{margin:.4em 0 1.1875em;font-size:16px;line-height:1.625}
//p.sub{font-size:13px}
//.align-right{text-align:right}
//.align-left{text-align:left}
//.align-center{text-align:center}
//.button{background-color:#3869D4;border-top:10px solid #3869D4;border-right:18px solid #3869D4;border-bottom:10px solid #3869D4;border-left:18px solid #3869D4;display:inline-block;color:#FFF;text-decoration:none;border-radius:3px;box-shadow:0 2px 3px rgba(0,0,0,0.16);-webkit-text-size-adjust:none;box-sizing:border-box}
//.button--green{background-color:#22BC66;border-top:10px solid #22BC66;border-right:18px solid #22BC66;border-bottom:10px solid #22BC66;border-left:18px solid #22BC66}
//.button--red{background-color:#FF6136;border-top:10px solid #FF6136;border-right:18px solid #FF6136;border-bottom:10px solid #FF6136;border-left:18px solid #FF6136}
//@media only screen and (max-width: 500px) {
//.button{width:100%!important;text-align:center!important}
//}
//.attributes{margin:0 0 21px}
//.attributes_content{background-color:#F4F4F7;padding:16px}
//.attributes_item{padding:0}
//.related{width:100%;margin:0;padding:25px 0 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
//.related_item{padding:10px 0;color:#CBCCCF;font-size:15px;line-height:18px}
//.related_item-title{display:block;margin:.5em 0 0}
//.related_item-thumb{display:block;padding-bottom:10px}
//.related_heading{border-top:1px solid #CBCCCF;text-align:center;padding:25px 0 10px}
//.discount{width:100%;margin:0;padding:24px;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#F4F4F7;border:2px dashed #CBCCCF}
//.discount_heading{text-align:center}
//.discount_body{text-align:center;font-size:15px}
//.social{width:auto}
//.social td{padding:0;width:auto}
//.social_icon{height:20px;margin:0 8px 10px;padding:0}
//.purchase{width:100%;margin:0;padding:35px 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
//.purchase_content{width:100%;margin:0;padding:25px 0 0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
//.purchase_item{padding:10px 0;color:#51545E;font-size:15px;line-height:18px}
//.purchase_heading{padding-bottom:8px;border-bottom:1px solid #EAEAEC}
//.purchase_heading p{margin:0;color:#85878E;font-size:12px}
//.purchase_footer{padding-top:15px;border-top:1px solid #EAEAEC}
//.purchase_total{margin:0;text-align:right;font-weight:700;color:#333}
//.purchase_total--label{padding:0 15px 0 0}
//body{background-color:#F4F4F7;color:#51545E}
//p{color:#51545E}
//p.sub{color:#6B6E76}
//.email-wrapper{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#F4F4F7}
//.email-content{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0}
//.email-masthead{padding:25px 0;text-align:center}
//.email-masthead_logo{width:94px}
//.email-masthead_name{font-size:16px;font-weight:700;color:#A8AAAF;text-decoration:none;text-shadow:0 1px 0 #fff}
//.email-body{width:100%;margin:0;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#FFF}
//.email-body_inner{width:570px;margin:0 auto;padding:0;-premailer-width:570px;-premailer-cellpadding:0;-premailer-cellspacing:0;background-color:#FFF}
//.email-footer{width:570px;margin:0 auto;padding:0;-premailer-width:570px;-premailer-cellpadding:0;-premailer-cellspacing:0;text-align:center}
//.email-footer p{color:#6B6E76}
//.body-action{width:100%;margin:30px auto;padding:0;-premailer-width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;text-align:center}
//.body-sub{margin-top:25px;padding-top:25px;border-top:1px solid #EAEAEC}
//.content-cell{padding:35px}
//@media only screen and (max-width: 600px) {
//.email-body_inner,.email-footer{width:100%!important}
//}
//@media (prefers-color-scheme: dark) {
//body,.email-body,.email-body_inner,.email-content,.email-wrapper,.email-masthead,.email-footer{background-color:#333!important;color:#FFF!important}
//p,ul,ol,blockquote,h1,h2,h3{color:#FFF!important}
//.attributes_content,.discount{background-color:#222!important}
//.email-masthead_name{text-shadow:none!important}
//}
//    </style>
//
//    <style type="text/css">
//      .f-fallback  {
//        font-family: Arial, sans-serif;
//      }
//    </style>
//
//  </head>
//  <body>
//<span class="preheader">Thanks for trying out '.$admin_site_name.'. We’ve pulled together some information and resources to help you get started.</span>
//<table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation">
//    <tr>
//        <td align="center">
//            <table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
//                <tr>
//                    <td class="email-masthead">
//                        <a href="'.$webpage_full_link.'" class="f-fallback email-masthead_name">
//                            '.$admin_site_name.'
//                        </a>
//                    </td>
//                </tr>
//                <!-- Email Body -->
//                <tr>
//                    <td class="email-body" width="100%" cellpadding="0" cellspacing="0">
//                        <table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
//                            <!-- Body content -->
//                            <tr>
//                                <td class="content-cell">
//                                    <div class="f-fallback">
//                                        <h1>Hi, ' . $first_name . '!</h1>
//                                        <p>Thanks for creating ' . $listing_name . '.Your Listing has been successfully created.</p>
//                                        <!-- Action -->
//                                        <p>For reference, here\'s your listing information:</p >
//                                        <table class="attributes" width = "100%" cellpadding = "0" cellspacing = "0" role = "presentation" >
//                                            <tr >
//                                                <td class="attributes_content" >
//                                                    <table width = "100%" cellpadding = "0" cellspacing = "0" role = "presentation" >
//                                                        <tr >
//                                                            <td class="attributes_item" >
//                                    <span class="f-fallback" >
//              <strong > Listing name:</strong > ' . $listing_name . '
//            </span>
//                                                            </td>
//                                                        </tr>
//                                                        <tr>
//                                                            <td class="attributes_item">
//                                    <span class="f-fallback">
//              <strong>Mobile Number :</strong> ' . $listing_mobile . '
//            </span>
//                                                            </td>
//                                                        </tr>
//                                                        <tr>
//                                                            <td class="attributes_item">
//                                    <span class="f-fallback">
//              <strong>Email Id :</strong> ' . $listing_email . '
//            </span>
//                                                            </td>
//                                                        </tr>
//                                                    </table>
//                                                </td>
//                                            </tr>
//                                        </table>
//
//                                        <p>You can login into your dashboard then you check all details of Listing.</p>
//                                        <!-- Action -->
//                                        <table class="body-action" align="center" width="100%" cellpadding="0" cellspacing="0" role="presentation">
//                                            <tr>
//                                                <td align="center">
//                                                    <table width="100%" border="0" cellspacing="0" cellpadding="0" role="presentation">
//                                                        <tr>
//                                                            <td align="center">
//                                                                <a href="'.$webpage_full_link_with_login.'" class="f-fallback button" target="_blank">Access your dashboard</a>
//                                                            </td>
//                                                        </tr>
//                                                    </table>
//                                                </td>
//                                            </tr>
//                                        </table>
//                                        <p>If you have any questions, feel free to <a href="mailto:{{support_email}}">email our customer success team</a>. (We\'re lightning quick at replying .)</p >
//                                        <p> Thanks,
//                                            <br > '.$admin_site_name.' Team</p>
//                                        <p><strong>P.S.</strong> Need immediate help getting started? Check out our <a href="'.$webpage_full_link.'">help documentation</a>. Or, just reply to this email, the '.$admin_site_name.' support team is always ready to help!</p>
//                                        <!-- Sub copy -->
//                                        <table class="body-sub" role="presentation">
//                                            <tr>
//                                                <td>
//                                                    <p class="f-fallback sub">If you’re having trouble with the button above, copy and paste the URL below into your web browser.</p>
//                                                    <p class="f-fallback sub">'.$webpage_full_link.'</p>
//                                                </td>
//                                            </tr>
//                                        </table>
//                                    </div>
//                                </td>
//                            </tr>
//                        </table>
//                    </td>
//                </tr>
//                <tr>
//                    <td>
//                        <table class="email-footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
//                            <tr>
//                                <td class="content-cell" align="center">
//                                    <p class="f-fallback sub align-center">&copy; '.$admin_footer_copyright.' '.$admin_site_name.'. All rights reserved.</p>
//                                    <p class="f-fallback sub align-center">
//                                        '.$admin_site_name.'
//                                        <br>'.$admin_address.'
//                                    </p>
//                                </td>
//                            </tr>
//                        </table>
//                    </td>
//                </tr>
//            </table>
//        </td>
//    </tr>
//</table>
//</body>';

            $headers1 = "From: " . "$admin_email" . "\r\n";
            $headers1 .= "Reply-To: " . "$admin_email" . "\r\n";
            $headers1 .= "MIME-Version: 1.0\r\n";
            $headers1 .= "Content-Type: text/html; charset=utf-8\r\n";


            mail($to1, $subject1, $message2, $headers1); //admin email

//****************************    client email ends    *************************

            if ($listing_type_id == 1) {

                $_SESSION['status_msg'] = "Your Listing has been Updated Successfully!!!";

                header('Location: admin-all-listings.php');
                exit;
            } else {

                header("Location: paypal_pay_admin.php?map_id=$listing_id&type_id=$listing_type_id");

                exit;
            }

//            $_SESSION['status_msg'] = "Your Listing has been Updated Successfully!!!";
//
//            header('Location: admin-all-listing.php');
        } else {

            $_SESSION['status_msg'] = "Oops!! Something Went Wrong Try Later!!!";

            header('Location: admin-edit-listings.php?code=' . $listing_code);
        }

        //    Listing Update Part Ends

    }
}else {

    $_SESSION['status_msg'] = "Oops!! Something Went Wrong Try Later!!!";

    header('Location: admin-all-listings.php');
}